<section class="left"><!-- section for page -->
		<ul><!-- ul element for list -->
			<li><a href="categories">Categories</a></li> <!-- list item -->
			<li><a href="furnitures">Furniture</a></li><!-- list item -->
			<li><a href="users">Users</a></li><!-- list item -->
			<li><a href="saveupdate">Add Update</a></li><!-- list item -->
		</ul><!-- ul element for list -->
</section><!-- closing of section -->