	<p>Welcome to Fran's Furniture. We're a family run furniture shop based in Northampton. 
	We stock a wide variety of modern and antique furniture including laps, bookcases, beds and sofas.</p>
	<hr>
	<h2>Updates</h2>
	<ul class="furniture">
<?php echo loadFromTemplate('../templates/user_home_update_template.php', ['updates'=>$updates]); ?>
	</ul>