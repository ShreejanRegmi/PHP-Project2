<p>Please call us on  01604 90345 or email <a href="mailto:enquiries@fransfurniture.co.uk">enquiries@fransfurniture.co.uk</a></p>
<br><br>
<hr>
<h2>Add Enquiry</h2>
<?php echo loadFromTemplate('../templates/contact_form_template.php', []); ?>