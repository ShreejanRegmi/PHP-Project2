<h2>Add Update</h2>
<?php echo loadFromTemplate('../templates/update_form_template.php', []) ?>