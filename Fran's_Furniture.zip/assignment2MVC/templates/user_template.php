<main class="home">
	<?php echo $content; ?>
</main>