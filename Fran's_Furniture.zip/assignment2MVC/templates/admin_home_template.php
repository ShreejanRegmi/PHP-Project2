<h2>You are now logged in as <?php echo $_SESSION['type']; ?></h2>
