<main class="home">
	<form action="login" method="POST">
		<label><b>Username</b></label><br>
		<!-- username input field -->
		<input type="text" name="username" placeholder="eg: Stevie" required><br><br>
		<label><b>Password</b></label><br>
		<!-- password input field -->
		<input type="password" name="password" placeholder="eg: Vaughan" required><br><br>
		<!-- submit button  -->
		<input type="submit" name="login" value="Login">
	</form>
</main>