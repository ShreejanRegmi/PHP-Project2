<?php
	$content="<p>Welcome to Fran's Furniture. We're a family run furniture shop based in Northampton. We stock a wide variety of modern and antique furniture including laps, bookcases, beds and sofas.</p>";
	echo loadFromTemplate('../templates/user_template.php', ['content'=>$content]);
?>
