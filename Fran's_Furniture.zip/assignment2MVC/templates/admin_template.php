<main class="admin">
	<?php require_once '../templates/admin_sidebar_template.php';  ?>
		<section class="right">
			<!-- content is loaded -->
			<?php echo $content; ?>
		</section>
</main>