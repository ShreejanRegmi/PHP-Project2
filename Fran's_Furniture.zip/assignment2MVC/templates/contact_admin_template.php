<h2>Review Enquiries</h2>
<?php echo loadFromTemplate('../templates/contact_table_template.php', ['enquiries'=>$enquiries]) ?>
