<?php
$content="<p>FAQ's coming soon..</p>";
echo loadFromTemplate('../templates/user_template.php', ['content'=>$content]);
?>
