<?php
	$title= "Fran's Furniture - FAQ";//title set for page
	$content=loadFromTemplate('../templates/faq_template.php', []);//template is loaded for main page
?>