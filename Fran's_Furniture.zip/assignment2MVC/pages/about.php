<?php
$title= "Fran's Furniture - About";//title is set
$content= loadFromTemplate('../templates/about_template.php', []);//content is set for the page
?>