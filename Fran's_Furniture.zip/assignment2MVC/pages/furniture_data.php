<?php
	$furnitureTable= new Table('furniture');//new table object is created
	$furnitures=$furnitureTable->findAllInDatabase();//find all database 
?>