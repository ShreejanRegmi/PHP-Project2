<?php
	$updatesTable= new Table('updates');//new table object created
	$updates=$updatesTable->findAllInDatabase();//find all data in table
?>